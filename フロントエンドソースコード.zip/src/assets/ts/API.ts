/*
 * @Author: zxy
 * @Date: 2021-06-16 14:44:27
 * @LastEditTime: 2021-07-28 20:03:45
 * @FilePath: /my-blog/src/assets/ts/API.ts
 */
// 本地测试APi
// const API = 'http://localhost:12138/'
// 国内线上API
// const API = 'https://serve.zouxinyu.club/'
// 日本线上API
const API = 'https://jserve.zouxinyu.club/'

export default API
