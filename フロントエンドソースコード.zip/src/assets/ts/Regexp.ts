/*
 * @Author: zxy
 * @Date: 2021-06-28 17:57:56
 * @LastEditTime: 2021-07-01 18:08:35
 * @FilePath: /my-blog/src/assets/ts/Regexp.ts
 */
const imageRegexp:RegExp = /.(gif|jpg|jpeg|png|svg+xml)$/

export {
  imageRegexp
}
